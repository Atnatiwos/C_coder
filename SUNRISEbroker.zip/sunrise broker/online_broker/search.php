

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search</title>
    <link rel="stylesheet" href="css/styles.css" />
    <link rel="stylesheet" href="css/search.css" />
    <style>
        body, html {
            font-family: Arial, sans-serif;
            background-image: none !important;
    color: black !important;}

    </style>
</head>
<body>
<?php include('php/header.php'); ?>
    <div class="container">
        <h2>Search Listings</h2>
        <form method="GET" action="searcher.php">
            <label for="listing_type">Listing Type:</label>
            <select id="listing_type" name="listing_type" required>
                <option value="Car">Car</option>
                <option value="House">House</option>
            </select>
            
            <label for="min_price">Min Price:</label>
            <input type="text" id="min_price" name="min_price" required>
            
            <label for="max_price">Max Price:</label>
            <input type="text" id="max_price" name="max_price" required>

            <div id="car_fields" style="display:none;">
                <label for="make">Make:</label>
                <input type="text" id="make" name="make">
                
                <label for="model">Model:</label>
                <input type="text" id="model" name="model">
                
                <label for="year">Year:</label>
                <input type="text" id="year" name="year">
            </div>

            <div id="house_fields" style="display:none;">
                <label for="city">City:</label>
                <input type="text" id="city" name="city">
                
                <label for="state">State:</label>
                <input type="text" id="state" name="state">
                
                <label for="zip_code">Zip Code:</label>
                <input type="text" id="zip_code" name="zip_code">
            </div>
            
            <input type="submit" value="Search">
        </form>
        

</body>
</html>
