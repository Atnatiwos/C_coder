
function loadContent(type) {
    const dynamicSection = document.getElementById('dynamic-section');
    const carHeader = document.getElementById('car-header');
    const houseHeader = document.getElementById('house-header');

    fetch(`${type}.php`)
        .then(response => response.text())
        .then(data => {
            dynamicSection.innerHTML = data;

            if (type === 'car') {
                carHeader.classList.add('active');
                houseHeader.classList.remove('active');
            } else if (type === 'house') {
                houseHeader.classList.add('active');
                carHeader.classList.remove('active');
            }
        })
        .catch(error => console.error('Error loading content:', error));
}
