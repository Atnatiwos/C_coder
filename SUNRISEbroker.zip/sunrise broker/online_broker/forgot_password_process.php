<?php
require 'php/configDB.php'; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    
    $stmt = $conn->prepare("SELECT user_id FROM user WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        //$reset_token = bin2hex(random_bytes(50));
        //$expiry = date("Y-m-d H:i:s", strtotime('+1 hour'));
        
        $stmt = $conn->prepare("UPDATE user SET username = ? WHERE user_id = ?");
        $stmt->bind_param("si", $reset_token, $user['user_id']);
        $stmt->execute();
        
        $reset_link = "http://localhost/reset_password.php?token=" . $reset_token;
        
        mail($email, "Password Reset Request", "Click this link to reset your password: " . $reset_link);
        
        echo "A password reset link has been sent to your email.";
    } else {
        echo "No user found with that email address.";
    }
}
?>
