<?php
include('php/userdata.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reviewer_id = $_POST['reviewer_id'];
    $reviewee_id = $_POST['reviewee_id'];
    $rating = $_POST['rating'];
    $comment = $_POST['comment'];

    $stmt = $conn->prepare("INSERT INTO Review (reviewer_id, reviewee_id, rating, comment) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiis", $reviewer_id, $reviewee_id, $rating, $comment);

    if ($stmt->execute()) {
        echo "<p>Review submitted successfully</p>";
    } else {
        echo "<p>Error submitting review: " . $stmt->error . "</p>";
    }

    $stmt->close();
}

$reviews = $conn->query("SELECT * FROM Review");

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review App</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            width: 80%;
            margin: auto;
        }
        h1, h2 {
            text-align: center;
        }
        form {
            margin-bottom: 20px;
        }
        label, input, textarea, select {
            display: block;
            width: 100%;
            margin-bottom: 10px;
        }
        input[type="text"], textarea, select {
            padding: 10px;
            font-size: 16px;
        }
        input[type="submit"] {
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
        }
        .review-list {
            list-style-type: none;
            padding: 0;
        }
        .review-list li {
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Review</h1>
        <h2>Submit Review</h2>
        <form method="POST" action="">
            <label for="reviewer_id">Reviewer ID:</label>
            <input type="text" id="reviewer_id" name="reviewer_id" required readonly value="<?php echo $_SESSION['user_id']; ?>">
            
            <label for="reviewee_id">Reviewee ID:</label>
            <input type="text" id="reviewee_id" name="reviewee_id" required>
            
            <label for="rating">Rating:</label>
            <select id="rating" name="rating" required>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
            </select>
            
            <label for="comment">Comment:</label>
            <textarea id="comment" name="comment" required></textarea>
            
            <input type="submit" value="Submit Review">
        </form>

        <h2>Reviews</h2>
        <ul class="review-list">
            <?php if ($reviews->num_rows > 0): ?>
                <?php while($row = $reviews->fetch_assoc()): ?>
                    <li>
                        <strong>Reviewer ID:</strong> <?php echo $row['reviewer_id']; ?><br>
                        <strong>Reviewee ID:</strong> <?php echo $row['reviewee_id']; ?><br>
                        <strong>Rating:</strong> <?php echo $row['rating']; ?><br>
                        <strong>Comment:</strong> <?php echo $row['comment']; ?><br>
                        <strong>Created At:</strong> <?php echo $row['created_at']; ?>
                    </li>
                <?php endwhile; ?>
            <?php else: ?>
                <li>No reviews found.</li>
            <?php endif; ?>
        </ul>
    </div>
</body>
</html>
