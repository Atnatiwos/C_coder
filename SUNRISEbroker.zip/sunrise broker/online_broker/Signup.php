<?php
include('php/configDB.php');

$usernameErr = $passwordErr = $emailErr = $error = $fullNameErr = $phoneNumberErr = $ageErr = $birthDateErr = $genderErr = $countryErr = $confirmPasswordErr ='';
$username = $password = $email = $fullName = $phoneNumber = $age = $birthDate = $gender =  $country = $confirmPassword ='';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $valid = true;

    function sanitize_input($data) {
      return htmlspecialchars(stripslashes(trim($data)));
  }

  // Get and sanitize input data
  $fullName = sanitize_input($_POST["fullName"]);
  $email = sanitize_input($_POST["email"]);
  $username = sanitize_input($_POST["username"]);
  $phoneNumber = sanitize_input($_POST["phoneNumber"]);
  $country = sanitize_input($_POST["country"]);
  $gender = sanitize_input($_POST["gender"]);
  $age = sanitize_input($_POST["age"]);
  $birthDate = sanitize_input($_POST["birthDate"]);
  $password = sanitize_input($_POST["password"]);
  $confirmPassword = sanitize_input($_POST["confirmPassword"]);


  if (empty($fullName)) {
  $fullNameErr = "Full Name is required."; 
  $valid = false;}
  elseif(!preg_match ("/^[a-zA-Z\s]+$/", $fullName)){
  $fullNameErr = "Full Name is must be letters and whitespace."; 
  $valid = false;}

  if (empty($phoneNumber) || !preg_match("/^[0-9]{10}$/", $phoneNumber)) 
  {$phoneNumberErr= "Valid Phone Number is required.";
    $valid = false;} 
  if (empty($age) || $age < 18 || $age > 100) {$ageErr = "Valid Age is required >18.";  
     $valid = false;}
  if (empty($birthDate)){ $birthDateErr = "Birth Date is required."; 
      $valid = false;}
  if (empty($country)) { $countryErr = "Country is required.";
    $valid = false;}
  if (empty($gender)) { $genderErr = "Gender is required."; 
  $valid = false;}

  
    if (empty($username)) {
        $usernameErr = "Username is required.";
        $valid = false;
    } elseif(!preg_match("/^[a-zA-Z0-9]*$/", $username)){
            $usernameErr = "Only letters and numbers allowed.";
            $valid = false;
    }


    if (empty($password)) {
        $passwordErr = "Password is required.";
        $valid = false;
    } elseif (strlen($password) < 6) {
            $passwordErr = "Password must be at least 6 characters.";
            $valid = false;
        }

    if ($password !== $confirmPassword) {$confirmPasswordErr = "Passwords do not match.";
      $valid = false;
        }

    if (empty($email)) {
        $emailErr = "Email is required.";
        $valid = false;
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format.";
            $valid = false;
        }

        if ($valid) {
          $query = "SELECT * FROM user WHERE email = ? OR username = ?";
          $stmt = $conn->prepare($query);
          $stmt->bind_param("ss", $email, $username);
          $stmt->execute();
          $result = $stmt->get_result();
      
          if ($result->num_rows > 0) {
              // Check which field is causing the duplication
              while ($row = $result->fetch_assoc()) {
                  if ($row['email'] === $email) {
                      $emailErr = "This email is already registered. Please use a different email.";
                  }
                  if ($row['username'] === $username) {
                      $usernameErr = "This username is already taken. Please choose a different username.";
                  }
              }
          } else {
              // Sanitize inputs and hash the password
              $username = $conn->real_escape_string($username);
              $password = password_hash($conn->real_escape_string($password), PASSWORD_BCRYPT);
              $email = $conn->real_escape_string($email);
      
              // Prepare the insert statement
              $sql = $conn->prepare("INSERT INTO user (full_name, email, username, phone_number, age, password, birth_date, country, gender) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
              $sql->bind_param("ssssissss", $fullName, $email, $username, $phoneNumber, $age, $password, $birthDate, $country, $gender);
      
              // Execute the insert statement
              if ($sql->execute()) {
                  header("Location: login.php");
              } else {
                  echo "Error: " . $sql . "<br>" . $mysqli->error;
              }
          }
      
          $stmt->close();
      }
    }
      
      $conn->close();


  
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" />
     <link rel="shortcut icon" href="image/icon.jpg" type="image/x-icon">
    <link rel="stylesheet" href="css/styles.css" />
    <title>Sign Up</title>
    <link rel="stylesheet" href="css/sign up.css">
          
  </head>
  <body>
  <?php include('php/header.php'); ?>
<main id="bodyy">
    <div class="containerr">
      <h1 class="form-title">Registration</h1>
      <form action="Signup.php" method="post">
        <div class="main-user-info">
          
          <div class="form-group fullname user-input-box"> 
          <label for="fullname">Full Name</label> 
          <input type="text" id="fullname" value="<?php echo $fullName; ?>" placeholder="Enter your full name" name = "fullName"> 
          <span style="color:red"><?php echo $fullNameErr; ?></span>
        </div> <div class="form-group email user-input-box"> <label for="email">Email Address</label> 
          
          <input type="email" id="email" name ="email" placeholder="Enter your email address" value="<?php echo $email; ?>"> 
          <span style="color:red"><?php echo $emailErr; ?></span></div> 
                 <div class="user-input-box form-group">
            <label for="username">Username</label>
            <input type="text"
                    id="username"
                    name="username"
                    placeholder="Enter Username" value="<?php echo $username ?>"
                    />
                    <span style="color:red"><?php echo $usernameErr; ?></span>
          </div>
          
          <div class="user-input-box form-group">
            <label for="phoneNumber">Phone Number</label>
            <input type="number"
                    id="phoneNumber"
                    name="phoneNumber"
                    placeholder="Enter Phone Number" value="<?php echo $phoneNumber; ?>"/>
                    <span style="color:red"><?php echo $phoneNumberErr; ?></span>
          </div>
          
          
          
          
          <div class="user-input-box">
            <label for="num">age</label>
            <input type="number"
                    id="num"
                    name="age"
                    placeholder="Enter your age" value="<?php echo $age; ?>"/>
                    <span style="color:red"><?php echo $ageErr; ?></span>
          </div>
          
          <div class="form-group password user-input-box"><label for="password">Password</label> 
          <input type="password" id="password" placeholder="Enter your password" value="<?php echo $password; ?>" name= "password">
          <span style="color:red"><?php echo $passwordErr; ?></span>
           <i id="pass-toggle-btn" class="fa-solid fa-eye"></i>
            </div> 
             <div class="user-input-box form-group">
            <label for="confirmPassword">Confirm Password</label>
            <input type="password"
                    id="confirmPassword"
                    name="confirmPassword"
                    placeholder="Confirm Password" value="<?php echo $confirmPassword; ?>"/>
                    <span style="color:red"><?php echo $confirmPasswordErr; ?></span>
          </div>
            <div class="form-group date user-input-box">
                 <label for="date">Birth Date</label> <input type="date" id="date" value="<?php echo $birthDate; ?>" placeholder="Select your date" name = "birthDate">
                 <span style="color:red"><?php echo $birthDateErr; ?></span>
                  </div> <div class="form-group gender user-inputl"> 
                  <label for="country">Country</label>
                <select id="country" name="country" value="<?php echo $country; ?>">
                    <option value="" selected disabled>Select your country</option>
                    <option value="Ethiopia" selected>Ethiopia</option>
                    <option value="USA">USA</option>
                    <option value="Canada">Canada</option>
                    <option value="Uganda">Uganda</option>
                </select>

                       <span style="color:red"><?php echo $countryErr; ?></span></div>        
                            
                </div>
        <div class="gender-details-box">
          <span class="gender-title">Gender</span>
          <div class="gender-category">
            <input type="radio" name="gender" id="male" value="male" value="<?php echo $gender; ?>" checked>
            <label for="male">Male</label>
            <input type="radio" name="gender" id ="female" value="female" value="<?php echo $gender; ?>">
            <label for="female">Female</label>
            <span style="color:red"><?php echo $genderErr; ?></span>
          </div>
        </div>
        <div class="form-submit-btn">
          <input type="submit" value="Register">
        </div>
      </form>
    </div>
    </main>
    <!-- footer-->
    <?php include('php/footer.php'); ?>
    <script>
    const form = document.querySelector("form"); 
    const passwordInput = document.getElementById("password"); 
    const passToggleBtn = document.getElementById("pass-toggle-btn"); 

    passToggleBtn.addEventListener('click', () => { passToggleBtn.className = passwordInput.type === "password" ? "fa-solid fa-eye-slash" : "fa-solid fa-eye"; passwordInput.type = passwordInput.type === "password" ? "text" : "password"; }); 
         
    </script>
    
   <!-- <script src="JavaScript/sign up.js"></script> -->
  </body>
</html>
