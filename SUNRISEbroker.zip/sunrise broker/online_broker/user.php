
<?php 
 include('php/userdata.php');
if(!isset($_SESSION['username']) && !isset($_COOKIE['username']) ){
    header("Location: login.php");
    exit();
}

$username = isset($_SESSION['username'])? $_SESSION['username']: $_COOKIE['username'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sell</title>
    <link rel="stylesheet" href="css/user.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

     <link rel="shortcut icon" href="image/icon.jpg" type="image/x-icon">
     <style>.choo, .chose{
    text-decoration: none !important;
    color: black !important;
    padding: 0;
    font-size: 1em;
}
</style>
</head>
<body>

<?php include('php/header.php'); ?>
    <div class="header">
        <span id="car-header" class="header-item">Car</span> | 
        <span id="house-header" class="header-item">House</span>
    </div>
    <div class="container">
        <div class="column dynamic-section" id="dynamic-section">
            <!-- Dynamic content-->

            <h1 class="glow-text">Welcome-<?php echo $username; ?></h1>

        </div><div class="static-section">
        <h5 id="userm" ><?php echo $username; ?></h5>
            <h4 class="h4h">user profile id- <?php echo $id;?></h4>
            <div ><ul class="useri">
                <li class="chose"><a href="recent.php" class="choo">recent</li>
                <li class="chose"><a href="search.php" class="choo">search</a></li>
                <li class="chose"><a href="favorite.php" class="choo">favorite</a></li>
                <li class="chose"><a href="mystory.php" class="choo">My story</a></li>
                <li class="chose"><a href="message.php" class="choo">message</a></li>
                <li class="chose"><a href="review.php" class="choo">review</a></li>
                <li class="chose"><a href="fetch_transactions.php" class="choo">transaction history</a></li>
            </ul></div>
            <h4 class="h4h">Click on a button to load what you want to sell</h4>
            <div class="buttons">
        <button  onclick="loadContent('car')">Car
        <span class="tooltip-text">sell your car</span></button>
        <button onclick="loadContent('house')">House
        <span class="tooltip-text">cell your house</span></button>
    </div>
        </div>

    </div>
    <div class="buttons">
        <button onclick="loadContent('car')">Car
        <span class="tooltip-text">sell your car</span></button>
        <button onclick="loadContent('house')">House
        <span class="tooltip-text">cell your house</span></button>
    </div>

    <?php include('php/footer.php'); ?>

    <script src="user.js"></script>
</body>
</html>
