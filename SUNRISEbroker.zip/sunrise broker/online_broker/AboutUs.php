<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

     <link rel="shortcut icon" href="image/icon.jpg" type="image/x-icon">
    <link rel="stylesheet" href="css/styles.css" />
    <link rel="stylesheet" href="css/About Us.css">
    <title>About Us</title>
    
  </head>
  <body>
  <?php include('php/header.php'); ?>

    
    <main id="bodyy"
	<div class="about-sec">
		<div class="about-img">
			<img src="image/logoa.jpg">
		</div>
		<div class="about-intro">
			<h3>About <span style="color: #00b894;"> Us !</h3>
			<p> We are happy working with you.This online broker website is a financial institution or platform that provides individuals with the ability to buy and sell financial securities, such as stocks, bonds, options, and mutual funds, through an online platform. These platforms facilitate trading activities for individual investors and traders by providing access to financial markets and tools for executing trades. </p>
				<div class="morr"><h3 id="morr">Read More</h3></div>
		</div>
	</div>
	</main>
	   <!-- footer-->
     <?php include('php/footer.php'); ?>
</body>
</html>
