<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download CSV</title>
    <style>
        .download-button {
            background-color: #4CAF50;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border: none;
        }
    </style>
</head>
<body>
    <h1>Download Transaction Data as CSV</h1>
    <form action="fetch_to_csv.php" method="post">
        <button type="submit" class="download-button">Download CSV</button>
    </form>
</body>
</html>
