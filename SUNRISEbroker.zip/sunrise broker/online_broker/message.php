<?php
include('php/userdata.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sender_id = $_POST['sender_id'];
    $receiver_id = $_POST['receiver_id'];
    $subject = $_POST['subject'];
    $body = $_POST['body'];

    $stmt = $conn->prepare("INSERT INTO Message (sender_id, receiver_id, subject, body) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiss", $sender_id, $receiver_id, $subject, $body);

    if ($stmt->execute()) {
        echo "<p>Message sent successfully</p>";
    } else {
        echo "<p>Error sending message: " . $stmt->error . "</p>";
    }

    $stmt->close();
}

$messages = $conn->query("SELECT * FROM Message");

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Message App</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            width: 80%;
            margin: auto;
        }
        h1, h2 {
            text-align: center;
        }
        form {
            margin-bottom: 20px;
        }
        label, input, textarea {
            display: block;
            width: 100%;
            margin-bottom: 10px;
        }
        input[type="text"], textarea {
            padding: 10px;
            font-size: 16px;
        }
        input[type="submit"] {
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
        }
        .message-list {
            list-style-type: none;
            padding: 0;
        }
        .message-list li {
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Message</h1>
        <h2>Send Message</h2>
        <form method="POST" action="">
            <label for="sender_id">Sender ID:</label>
            <input type="text" id="sender_id" name="sender_id" required readonly value="<?php echo $_SESSION['user_id']; ?>">
            
            <label for="receiver_id">Receiver ID:</label>
            <input type="text" id="receiver_id" name="receiver_id" required>
            
            <label for="subject">Subject:</label>
            <input type="text" id="subject" name="subject" required>
            
            <label for="body">Body:</label>
            <textarea id="body" name="body" required></textarea>
            
            <input type="submit" value="Send Message">
        </form>

        <h2>Messages</h2>
        <ul class="message-list">
            <?php if ($messages->num_rows > 0): ?>
                <?php while($row = $messages->fetch_assoc()): ?>
                    <li>
                        <strong>From:</strong> <?php echo $row['sender_id']; ?> 
                        <strong>To:</strong> <?php echo $row['receiver_id']; ?> 
                        <strong>Subject:</strong> <?php echo $row['subject']; ?><br>
                        <strong>Body:</strong> <?php echo $row['body']; ?><br>
                        <strong>Sent At:</strong> <?php echo $row['sent_at']; ?>
                    </li>
                <?php endwhile; ?>
            <?php else: ?>
                <li>No messages found.</li>
            <?php endif; ?>
        </ul>
    </div>
</body>
</html>
