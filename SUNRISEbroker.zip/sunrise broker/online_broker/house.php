<?php
include('php/userdata.php');

function displayError($errors, $field) {
    if (isset($errors[$field])) {
        return '<span class="error">' . htmlspecialchars($errors[$field]) . '</span>';
    }
    return '';
}

function retainValue($field) {
    return isset($_POST[$field]) ? htmlspecialchars($_POST[$field]) : '';
}

$errors = [];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input
    $type = isset($_POST['type']) ? htmlspecialchars(trim($_POST['type'])) : '';
    $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
    $address = isset($_POST['address']) ? htmlspecialchars(trim($_POST['address'])) : '';
    $city = isset($_POST['city']) ? htmlspecialchars(trim($_POST['city'])) : '';
    $state = isset($_POST['state']) ? htmlspecialchars(trim($_POST['state'])) : '';
    $zip_code = filter_input(INPUT_POST, 'zip_code', FILTER_VALIDATE_REGEXP, [
        "options" => ["regexp" => "/^\d{5}$/"]
    ]);
    $bedrooms = filter_input(INPUT_POST, 'bedrooms', FILTER_VALIDATE_INT);
    $bathrooms = filter_input(INPUT_POST, 'bathrooms', FILTER_VALIDATE_INT);
    $square_feet = filter_input(INPUT_POST, 'square_feet', FILTER_VALIDATE_INT);
    $year_built = filter_input(INPUT_POST, 'year_built', FILTER_VALIDATE_INT);
    $description = isset($_POST['description']) ? htmlspecialchars(trim($_POST['description'])) : '';

    // Check for validation errors
    if (!$type) $errors['type'] = "Type is required.";
    if ($price === false) $errors['price'] = "Invalid price.";
    if (!$address) $errors['address'] = "Address is required.";
    if (!$city) $errors['city'] = "City is required.";
    if (!$state) $errors['state'] = "State is required.";
    if (!$zip_code) $errors['zip_code'] = "Invalid zip code.";
    if ($bedrooms === false) $errors['bedrooms'] = "Invalid number of bedrooms.";
    if ($bathrooms === false) $errors['bathrooms'] = "Invalid number of bathrooms.";
    if ($square_feet === false) $errors['square_feet'] = "Invalid square feet.";
    if ($year_built === false) $errors['year_built'] = "Invalid year built.";
    if (!$description) $errors['description'] = "Description is required.";

    if (empty($errors)) {
        

        $stmt = $conn->prepare("INSERT INTO House (user_id,type, price, address, city, state, zip_code, bedrooms, bathrooms, square_feet, year_built, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)");
        $stmt->bind_param("isdsssiiisis",$id, $type, $price, $address, $city, $state, $zip_code, $bedrooms, $bathrooms, $square_feet, $year_built, $description);

        if ($stmt->execute()) {
            $_SESSION['image_type'] = "house";
            header("Location: image.php");

        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>House Listing Form</title>
    <style>
        body,html{
            background-image: none !important;
        }

        .containerr {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin: 10px 0 5px;
            color: #555;
        }
        input, select, textarea {
            padding: 10px;
            margin-bottom: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
        }
        textarea {
            resize: vertical;
        }
        .error {
            color: red;
            font-size: 0.875em;
            margin-top: -5px;
            margin-bottom: 10px;
        }
        input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 4px;
        cursor: pointer;
    }
    </style>
     <link rel="shortcut icon" href="image/icon.jpg" type="image/x-icon">
    <link rel="stylesheet" href="css/styles.css" />
</head>
<body>
<?php include('php/header.php'); ?>

<div class="containerr">
    <h2>House selling Form</h2>
    <form action="house.php" method="POST" novalidate>
        <label for="type">Type:</label>
        <select id="type" name="type" required>
            <option value="">Select Type</option>
            <option value="Apartment" <?= retainValue('type') == 'Apartment' ? 'selected' : '' ?>>Apartment</option>
            <option value="House" <?= retainValue('type') == 'House' ? 'selected' : '' ?>>House</option>
            <option value="Condo" <?= retainValue('type') == 'Condo' ? 'selected' : '' ?>>Condo</option>
            <option value="Townhouse" <?= retainValue('type') == 'Townhouse' ? 'selected' : '' ?>>Townhouse</option>
        </select>
        <?php echo displayError($errors, 'type'); ?>

        <label for="price">Price:</label>
        <input type="number" id="price" name="price" value="<?= retainValue('price') ?>" required>
        <?php echo displayError($errors, 'price'); ?>

        <label for="address">Address:</label>
        <input type="text" id="address" name="address" value="<?= retainValue('address') ?>" required>
        <?php echo displayError($errors, 'address'); ?>

        <label for="city">City:</label>
        <input type="text" id="city" name="city" value="<?= retainValue('city') ?>" required>
        <?php echo displayError($errors, 'city'); ?>

        <label for="state">State:</label>
        <input type="text" id="state" name="state" value="<?= retainValue('state') ?>" required>
        <?php echo displayError($errors, 'state'); ?>

        <label for="zip_code">Zip Code:</label>
        <input type="text" id="zip_code" name="zip_code" pattern="\d{5}" value="<?= retainValue('zip_code') ?>" required>
        <?php echo displayError($errors, 'zip_code'); ?>

        <label for="bedrooms">Bedrooms:</label>
        <input type="number" id="bedrooms" name="bedrooms" value="<?= retainValue('bedrooms') ?>" required>
        <?php echo displayError($errors, 'bedrooms'); ?>

        <label for="bathrooms">Bathrooms:</label>
        <input type="number" id="bathrooms" name="bathrooms" value="<?= retainValue('bathrooms') ?>" required>
        <?php echo displayError($errors, 'bathrooms'); ?>

        <label for="square_feet">Square Feet:</label>
        <input type="number" id="square_feet" name="square_feet" value="<?= retainValue('square_feet') ?>" required>
        <?php echo displayError($errors, 'square_feet'); ?>

        <label for="year_built">Year Built:</label>
        <input type="number" id="year_built" name="year_built" value="<?= retainValue('year_built') ?>" required>
        <?php echo displayError($errors, 'year_built'); ?>

        <label for="description">Description:</label>
        <textarea id="description" name="description" rows="4" required><?= retainValue('description') ?></textarea>
        <?php echo displayError($errors, 'description'); ?>

        <input type="submit" value="Submit">
    </form>
</div>
<?php include('php/footer.php'); ?>
</body>
</html>
