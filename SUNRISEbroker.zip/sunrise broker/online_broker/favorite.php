<?php
include('php/userdata.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'];
    $listing_id = $_POST['listing_id'];
    $listing_type = $_POST['listing_type'];

    $stmt = $conn->prepare("INSERT INTO Favorite (user_id, listing_id, listing_type) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $user_id, $listing_id, $listing_type);

    if ($stmt->execute()) {
        echo "<p>Listing added to favorites successfully</p>";
    } else {
        echo "<p>Error adding listing to favorites: " . $stmt->error . "</p>";
    }

    $stmt->close();
}

$favorites = $conn->query("SELECT * FROM Favorite");

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Favorite Listings App</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            width: 80%;
            margin: auto;
        }
        h1, h2 {
            text-align: center;
        }
        form {
            margin-bottom: 20px;
        }
        label, input, select {
            display: block;
            width: 100%;
            margin-bottom: 10px;
        }
        input[type="text"], select {
            padding: 10px;
            font-size: 16px;
        }
        input[type="submit"] {
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
        }
        .favorite-list {
            list-style-type: none;
            padding: 0;
        }
        .favorite-list li {
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Favorite</h1>
        <h2>Add to Favorites</h2>
        <form method="POST" action="">
            <label for="user_id" >User ID:</label>
            <input type="text" id="user_id" name="user_id" required readonly value="<?php echo $_SESSION['user_id']; ?>">
            
            <label for="listing_id">Listing ID:</label>
            <input type="text" id="listing_id" name="listing_id" required>
            
            <label for="listing_type">Listing Type:</label>
            <select id="listing_type" name="listing_type" required>
                <option value="Car">Car</option>
                <option value="House">House</option>
            </select>
            
            <input type="submit" value="Add to Favorites">
        </form>

        <h2>Favorite Listings</h2>
        <ul class="favorite-list">
            <?php if ($favorites->num_rows > 0): ?>
                <?php while($row = $favorites->fetch_assoc()): ?>
                    <li>
                        <strong>User ID:</strong> <?php echo $row['user_id']; ?><br>
                        <strong>Listing ID:</strong> <?php echo $row['listing_id']; ?><br>
                        <strong>Listing Type:</strong> <?php echo $row['listing_type']; ?><br>
                        <strong>Added At:</strong> <?php echo $row['created_at']; ?>
                    </li>
                <?php endwhile; ?>
            <?php else: ?>
                <li>No favorite listings found.</li>
            <?php endif; ?>
        </ul>
    </div>
</body>
</html>
