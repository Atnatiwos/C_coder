
<?php
if (session_status() == PHP_SESSION_NONE) {
  session_start();
}
?>
<header>
      <div id="brand"><a href="/">OnlineBroker</a></div>
      <nav>
        <ul>
        <li><a href="index.php">Home</a></li>
        
        <li><a href="search.php">search</a></li>
                  <li><a href="shop.php">Shop</a></li>
          <li><a href="AboutUs.php">About us</a></li>

                <?php if (isset($_SESSION['username']) || isset($_COOKIE['username'])): ?>
                  <li><a href="user.php">user</a></li>
          <li id="signup"><a href="php/logout.php">logout</a></li>
                <?php else: ?>
                              <li id="login"><a href="login.php" >Login</a></li>
          <li id="signup"><a href="signup.php">Signup</a></li>
                <?php endif; ?>

        </ul>
      </nav>
      <div id="hamburger-icon" onclick="toggleMobileMenu(this)">
        <div class="bar1"></div>
        <div class="bar2"></div>
        <div class="bar3"></div>
        <ul class="mobile-menu">
          <li><a href="index.php">Home</a></li>
          <li><a href="user.php">user</a></li>
          <li><a href="shop.php">Shop</a></li>
          <li><a href="AboutUs.php">About us</a></li>
          <li id="login"><a href="login.php" >Login</a></li>
          <li id="signup"><a href="signup.php">Signup</a></li>
        </ul>
      </div>
    </header>    
    </body>
    </html>
    