
<html>
<head>
<link rel="stylesheet" href="css/styles.css" />
</head>
<body>
<footer>  
        
    <div class="footer">
        <ul>
            <li class="fo"><a href="index.php">Home</a></li>
            <li class="fo"><a href="AboutUs.php">About Us</a></li>
            <li class="fo"><a href="shop.php">Services</a></li>
            <li class="fo"><a href="#">Contact Us</a></li>
        </ul>
        <div class="social-icons">
            <a href="#"><i class="fab fa-facebook"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-linkedin"></i></a>
                 <a href="#"><i class="fab fa-telegram"></i></a>
        </div>
        <p id="conc">&copy; 2024 ETHIOPIA.  All Rights Reserved.</p>
       
    </div>
       </footer>
       <script src="JavaScript/index.js"></script>
       </body>
       </html>