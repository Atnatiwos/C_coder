<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();}
if(!isset($_SESSION['username']) && !isset($_COOKIE['username']) ){
    header("Location: login.php");
    exit();
}
include('php/configDB.php');
$sql = "SELECT * FROM user WHERE username = ?";
$username = isset($_SESSION['username'])? $_SESSION['username']: $_COOKIE['username'];
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

            $row = $result->fetch_assoc();
           $username= $row['username'];
        $id=$row['user_id'];
?>