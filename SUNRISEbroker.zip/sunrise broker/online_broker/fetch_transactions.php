<?php

include('php/userdata.php');


$sql = "SELECT transaction_id, buyer_id, seller_id, listing_type, price, transaction_date, status FROM Transaction WHERE buyer_id=?";
$stmt = $conn->prepare($sql);
$userid = $_SESSION['user_id'];
$stmt->bind_param("i", $userid);
$stmt->execute();
$result = $stmt->get_result();

$transactions = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $transactions[] = $row;
    }
}

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Transactions</title>
    
    <style>
        th, td{
    padding: 7px 15px;
}
th{
    text-transform: capitalize;
    font-size: 90%;
    border-bottom: 2px solid;
    text-align: left;
}
tr:nth-child(even){
    background-color: #f2f2f2;
}
tr:nth-child(odd){
    background-color: #fff;
}

    </style>
</head>
<body>
    <h2>Transactions</h2>
    <table>
        <tr>
            <th>Transaction ID</th>
            <th>Buyer ID</th>
            <th>Seller ID</th>
            <th>Price</th>
            <th>Listing Type</th>
            <th>Transaction Date</th>
            <th>Status</th>
        </tr>
        <?php foreach ($transactions as $row): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['transaction_id']); ?></td>
                <td><?php echo htmlspecialchars($row['buyer_id']); ?></td>
                <td><?php echo htmlspecialchars($row['seller_id']); ?></td>
                <td><?php echo htmlspecialchars($row['price']); ?></td>
                <td><?php echo htmlspecialchars($row['listing_type']); ?></td>
                <td><?php echo htmlspecialchars($row['transaction_date']); ?></td>
                <td><?php echo htmlspecialchars($row['status']); ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
    <?php include('filecsv.php'); ?>
</body>
</html>
