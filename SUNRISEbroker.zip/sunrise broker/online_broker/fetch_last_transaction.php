<?php
include('php/userdata.php');

if (isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];

    $sql = "
        SELECT 
            transaction_id, 
            buyer_id, 
            seller_id, 
            listing_type, 
            price, 
            transaction_date, 
            status
        FROM 
            Transaction
        WHERE 
            buyer_id = ? OR seller_id = ?
        ORDER BY 
            transaction_date DESC
        LIMIT 1
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $user_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo "<h3>Last Transaction Details:</h3>";
        echo "Transaction ID: " . $row["transaction_id"] . "<br>";
        echo "Buyer ID: " . $row["buyer_id"] . "<br>";
        echo "Seller ID: " . $row["seller_id"] . "<br>";
        echo "Listing Type: " . $row["listing_type"] . "<br>";
        echo "Price: " . $row["price"] . "<br>";
        echo "Transaction Date: " . $row["transaction_date"] . "<br>";
        echo "Status: " . $row["status"] . "<br>";
    } else {
        echo "No transactions found for user ID: " . $user_id;
    }

    $stmt->close();
}

$conn->close();
?>
