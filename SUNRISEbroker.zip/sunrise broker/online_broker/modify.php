<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id'])) {
    include('php/userdata.php');

    $id = intval($_POST['id']);
    $newName = $_POST['newName'];
    $stmt = $conn->prepare("UPDATE images SET image_name = ? WHERE user_id = ?");
    $stmt->bind_param("si", $newName, $id);

    if ($stmt->execute()) {
        echo "Image modified successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
    header("Location: image.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modify Image</title>
</head>
<body>
    <div class="container">
        <h1>Modify Image</h1>
        <form action="modify.php" method="post">
            <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
            <label for="newName">New Name:</label>
            <input type="text" id="newName" name="newName" required>
            <input type="submit" value="Modify Image">
        </form>
    </div>
</body>
</html>
