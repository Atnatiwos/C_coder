<?php
session_start();
include('php/configDB.php');

$usernameErr = $passwordErr = $error = '';
$username = $password = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $valid = true;
    $remember_me = isset($_POST['remember_me']);
    
    function sanitize_input($data) {
        return htmlspecialchars(stripslashes(trim($data)));
    }
  
    if (empty($_POST['username'])) {
        $usernameErr = "Username is required.";
        $valid = false;
    } else {
        $username = sanitize_input($_POST['username']);
    }

    if (empty($_POST['password'])) {
        $passwordErr = "Password is required.";
        $valid = false;
    } else {
        $password = sanitize_input($_POST['password']);
    }

    if ($valid) {
        $username = $conn->real_escape_string($username);

        $sql = "SELECT * FROM user WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
           if (password_verify($password, $row['password'])) {
                $_SESSION['username'] = $username;
                $_SESSION['user_id'] = $row['user_id'];
                $_SESSION['username'] = $row['username'];
                if ($remember_me) {
                setcookie('username',$username, time() + (86400 * 30), "/" );
                }
                header("Location: user.php");
                exit(); 
            } else {
                $error = "Invalid password.";
            }
        } else {
            $error = "No user found with that username.";
        }

        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
     <link rel="shortcut icon" href="image/icon.jpg" type="image/x-icon">
    <link rel="stylesheet" href="css/styles.css" />
    <title>Login</title>
    <link rel="stylesheet" href="css/log in.css">
    
  </head>
  <body>
  <?php include('php/header.php'); ?>
<main id="bodyy">
    
  <div class="wrapper">
    <form action="login.php" method="post">
      <h1>Login</h1>
      <span style="color:red"><?php echo $error; ?> </span>
      <div class="input-box">
        <input type="text" placeholder="Username" name = "username" value="<?php echo $username; ?>">
        <i class='bx bxs-user'></i>
        <span style="color:red"><?php echo $usernameErr;?> </span>
      </div>
      <div class="input-box">
        <input type="password" placeholder="Password"  name="password">
        <i class='bx bxs-lock-alt' ></i>
        <span style="color:red"><?php echo $passwordErr; ?></span>
      </div>
      <div class="remember-forgot">
        <label><input type="checkbox" name="remember_me">Remember Me</label>
        <a href="forgot_password.php">Forgot Password</a>
      </div>
      <button type="submit" class="btn">Login</button>
      <div class="register-link">
        <p>Dont have an account? <a href="signup.php">Register</a></p>
      </div>
    </form>
  </div>
  </main>
  
     <!-- footer-->
     <?php include('php/footer.php'); ?>
</body>
</html>
