<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include('php/userdata.php');

    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
    foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
        $fileName = basename($_FILES['images']['name'][$key]);
        $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $fileData = file_get_contents($tmp_name);
        $image_type = $_SESSION['image_type'];
       // $ima = $conn->real_escape_string($fileData);
       $stmt=$conn->prepare("SELECT COUNT(*) FROM images WHERE image_name =?");
       $stmt->bind_param("s",$fileName);
       $stmt->execute();
       $stmt->bind_result($count);
       $stmt->fetch();
       $stmt->close();


        if (!in_array($fileType, $allowedTypes)) {
            echo "Sorry, only JPG, JPEG, PNG, and GIF files are allowed.";
            continue;
        }
        
        if($count>0){
            echo "sorry, file already exit";
            continue;
        }
        if(($_FILES['images']['size'][$key]) > 2 * 1024 * 1024){
            echo "file ". $fileName. " is too large , please upload a file smaller than 2MB.";
            continue;
        }

        $mimeType = mime_content_type($tmp_name);
        $stmt = $conn->prepare("INSERT INTO images (user_id,image_name, type, image_type,image) VALUES (?, ?, ?,?,?)");
       $null = NULL;
        $stmt->bind_param("isssb",$id, $fileName, $mimeType, $image_type, $null);
        $stmt->send_long_data(4, $fileData);


        if ($stmt->execute()) {
            echo "The file " . htmlspecialchars($fileName) . " has been uploaded.<br>";
            header("Location: image.php");
        } else {
            echo "Error: " . $stmt->error . "<br>";
        }

        $stmt->close();
    }

    $conn->close();
    
}
?>
