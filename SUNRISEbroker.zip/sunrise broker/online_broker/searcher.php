<?php


include('php/configDB.php');

$car= [];
$house= [];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $listing_type = $_GET['listing_type'];
    $min_price = $_GET['min_price'];
    $max_price = $_GET['max_price'];

    if ($listing_type === 'Car') {
        $make = $_GET['make'];
        $model = $_GET['model'];
        $year = $_GET['year'];

        $sql = "SELECT * FROM Car WHERE price BETWEEN ? AND ?";
        $params = [$min_price, $max_price];

        if ($make) {
            $sql .= " AND make = ?";
            $params[] = $make;
        }
        if ($model) {
            $sql .= " AND model = ?";
            $params[] = $model;
        }
        if ($year) {
            $sql .= " AND year = ?";
            $params[] = $year;
        }

        $stmt = $conn->prepare($sql);
        $stmt->bind_param(str_repeat("s", count($params)), ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        $cars = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    } elseif ($listing_type === 'House') {
        $city = $_GET['city'];
        $state = $_GET['state'];
        $zip_code = $_GET['zip_code'];

        $sql = "SELECT * FROM House WHERE price BETWEEN ? AND ?";
        $params = [$min_price, $max_price];

        if ($city) {
            $sql .= " AND city = ?";
            $params[] = $city;
        }
        if ($state) {
            $sql .= " AND state = ?";
            $params[] = $state;
        }
        if ($zip_code) {
            $sql .= " AND zip_code = ?";
            $params[] = $zip_code;
        }

        $stmt = $conn->prepare($sql);
        $stmt->bind_param(str_repeat("s", count($params)), ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        $houses = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    }
}

$conn->close();
?>

<html>
<head>
    
<head>
    <body>
    <h2>Search Results</h2>
        <ul class="listing-list">
            <?php if ($_SERVER['REQUEST_METHOD'] === 'GET' && $listing_type === 'Car' && count($cars) > 0): ?>
                <?php foreach ($cars as $car): ?>
                    <li>
                        <strong>Make:</strong> <?php echo $car['make']; ?><br>
                        <strong>Model:</strong> <?php echo $car['model']; ?><br>
                        <strong>Year:</strong> <?php echo $car['year']; ?><br>
                        <strong>Price:</strong> $<?php echo $car['price']; ?><br>
                        <strong>Description:</strong> <?php echo $car['description']; ?><br>
                        <strong>Added At:</strong> <?php echo $car['created_at']; ?>
                    </li>
                <?php endforeach; ?>
            <?php elseif ($_SERVER['REQUEST_METHOD'] === 'GET' && $listing_type === 'House' && count($houses) > 0): ?>
                <?php foreach ($houses as $house): ?>
                    <li>
                        <strong>Address:</strong> <?php echo $house['address']; ?><br>
                        <strong>City:</strong> <?php echo $house['city']; ?><br>
                        <strong>State:</strong> <?php echo $house['state']; ?><br>
                        <strong>Zip Code:</strong> <?php echo $house['zip_code']; ?><br>
                        <strong>Price:</strong> $<?php echo $house['price']; ?><br>
                        <strong>Description:</strong> <?php echo $house['description']; ?><br>
                        <strong>Added At:</strong> <?php echo $house['created_at']; ?>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li>No listings found.</li>
            <?php endif; ?>
        </ul>
    </div>

    <script>
        document.getElementById('listing_type').addEventListener('change', function() {
            var listingType = this.value;
            if (listingType === 'Car') {
                document.getElementById('car_fields').style.display = 'block';
                document.getElementById('house_fields').style.display = '
                document.getElementById('house_fields').style.display = 'none';
            } else if (listingType === 'House') {
                document.getElementById('car_fields').style.display = 'none';
                document.getElementById('house_fields').style.display = 'block';
            }
        });

        document.getElementById('listing_type').dispatchEvent(new Event('change'));
    </script>

    </body>
    </html>