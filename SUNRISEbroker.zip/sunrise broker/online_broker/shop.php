<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

     <link rel="shortcut icon" href="image/icon.jpg" type="image/x-icon">
    <link rel="stylesheet" href="css/styles.css" />
    <title>Shop</title>
    
     <link rel="stylesheet" href="css/shop.css">
  </head>

<body>
    <div id="brandd">OnlineBroker</div>
    <?php include('php/header.php'); ?>
    
    <!-- for cars-->
    
    <div class=" choice"><h1>CURRENT  <span>CARS</span></h1></div>
    
    <main class="container">  
        
         <?php
           include('php/configDB.php');
           $itype= "car";

           $sql = "SELECT * FROM images WHERE image_type = ?";
           $stmt = $conn->prepare($sql);
           $stmt->bind_param("s", $itype);
           $stmt->execute();
           $result = $stmt->get_result();
   
               $row = $result->fetch_assoc();
            while ($row = $result->fetch_assoc()) {
                echo '<div class="image-item comn ">';
                echo '<img src="data:image/' . $row['type'] . ';base64,' . base64_encode($row['image']) . '" alt="' . htmlspecialchars($row['image_name']) . '" onclick="showActions(' . $row['image_id'] . ')">';
                echo '<h2>'.$row['image_name'].'</h2>';
                echo '<div class="buy">';
                echo '<a href="buy.php?id=' . $row['image_id'] . '" > BUY <span> NOW</span> </a>';
                echo '</div>';
               // echo '<a href="delete.php?id=' . $row['image_id'] . '">Modify</a>';
                echo '</div>';
                echo '</div>';
            }
            $conn->close();
            ?>




    </main>
     
    <!-- for house -->
    
       <div class=" choice"><h1>CURRENT  <span>HOUSES</span></h1></div>
    
    <main class="container">  
        

         <?php
           include('php/configDB.php');
           $itype= "house";

           $sql = "SELECT * FROM images WHERE image_type = ?";
           $stmt = $conn->prepare($sql);
           $stmt->bind_param("s", $itype);
           $stmt->execute();
           $result = $stmt->get_result();
   
               $row = $result->fetch_assoc();
            while ($row = $result->fetch_assoc()) {
                echo '<div class="image-item comn ">';
                echo '<div class="imo">';
                echo '<img src="data:image/' . $row['type'] . ';base64,' . base64_encode($row['image']) . '" alt="' . htmlspecialchars($row['image_name']) . '" onclick="showActions(' . $row['image_id'] . ')">';
                echo '</div>';
                echo '<h2>'.$row['image_name'].'</h2>';
                echo '<div class="buy">';
                echo '<a href="buy.php?id=' . $row['image_id'] . '" > BUY <span> NOW</span> </a>';
                echo '</div>';
               // echo '<a href="delete.php?id=' . $row['image_id'] . '">Modify</a>';
                echo '</div>';
                echo '</div>';
            }
            $conn->close();
            ?>
    </main>
    <!-- footer--> 
        
    <?php include('php/footer.php'); ?>
    
</body>
</html>
