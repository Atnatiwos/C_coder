<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Image</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input[type="file"], input[type="submit"] {
            margin: 10px 0;
        }
        a{
            padding: 4px;
            margin: 3px;
            text-decoration: none;
            font-size: 1em;
            color: black;
            text-align: center;
        }
        a:hover{
            color: red;

        }
        .gallery {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
        }
        .gallery img {
            max-width: 100%;
            height: auto;
            cursor: pointer;
        }
        .finish{
            position: fixed;
            bottom: 20px;
            float: right;
            font-size: 1.5em;
            margin-top: 5px;
            z-index: 1;
        }
        .gallery .actions {
            display: flex;
            justify-content: space-around;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Upload Image</h1>
        <form action="upload.php" method="post" enctype="multipart/form-data">
            <input type="file" name="images[]" multiple required>
            <input type="submit" value="Upload Images">
        </form>
        <h2>Uploaded Images</h2>
        <p>after you upload your file enter the image to modify or delete</p>
        <div class="gallery">
            <?php
           include('php/userdata.php');

           $sql = "SELECT * FROM images WHERE user_id = ?";
           $stmt = $conn->prepare($sql);
           $stmt->bind_param("i", $id);
           $stmt->execute();
           $result = $stmt->get_result();
   
               $row = $result->fetch_assoc();
            while ($row = $result->fetch_assoc()) {
                echo '<div class="image-item">';
                echo '<img src="data:image/' . $row['type'] . ';base64,' . base64_encode($row['image']) . '" alt="' . htmlspecialchars($row['image_name']) . '" onclick="showActions(' . $row['image_id'] . ')">';
                echo '<div class="actions" id="actions-' . $row['image_id'] . '" style="display:none;">';
                echo '<a href="delete.php?id=' . $row['image_id'] . '">Delete</a>';
                echo '<a href="modify.php?id=' . $row['image_id'] . '">Modify</a>';
                echo '</div>';
                echo '</div>';
            }
            $conn->close();
            ?>
        </div>
        <button class="finish"><a href="user.php">finish</a></button>
    </div>
    <script>
        function showActions(id) {
            const actions = document.getElementById('actions-' + id);
            actions.style.display = actions.style.display === 'none' ? 'block' : 'none';
        }
    </script>
</body>
</html>
