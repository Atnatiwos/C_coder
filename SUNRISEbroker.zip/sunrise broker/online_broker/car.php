<?php
include('php/userdata.php');

$errors = [];



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $make = filter_input(INPUT_POST, 'make', FILTER_SANITIZE_SPECIAL_CHARS);
    $model = filter_input(INPUT_POST, 'model', FILTER_SANITIZE_SPECIAL_CHARS);
    $year = filter_input(INPUT_POST, 'year', FILTER_VALIDATE_INT);
    $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
    $mileage = filter_input(INPUT_POST, 'mileage', FILTER_VALIDATE_INT);
    $color = filter_input(INPUT_POST, 'color', FILTER_SANITIZE_SPECIAL_CHARS);
    $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_SPECIAL_CHARS);
    $location = filter_input(INPUT_POST, 'location', FILTER_SANITIZE_SPECIAL_CHARS);

    $year_regex = "/^(19|20)\d{2}$/";
    $name_regex = "/^[a-zA-Z]*$/";

    if (!preg_match($year_regex, $year)) {
        $errors['year'] = "Invalid year format. Please enter a valid year (1900-2099).";
    }

    if (empty($make)) {
        $errors['make'] = "Make is required.";
    }
    if (empty($model)) {
        $errors['model'] = "Model is required.";
    }
    if (empty($price) && $price !== 0) {
        $errors['price'] = "Price is required.";
    }
    if (empty($mileage) && $mileage !== 0) {
        $errors['mileage'] = "Mileage is required.";
    }
    if (empty($color)) {
        $errors['color'] = "Color is required.";
        
    }
    if(!preg_match($name_regex,$color)){
        $errors['color'] = "invalid color name.";
    }
    if (empty($description)) {
        $errors['description'] = "Description is required.";
        
    }
    if (empty($location)) {
        $errors['location'] = "Location is required.";
        
    }

    if (empty($errors)) {
        $sql = "INSERT INTO Car (user_id, make, model, year, price, mileage, color, description, location) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $user_id = 1; 

            $stmt->bind_param("isssdisss", $id, $make, $model, $year, $price, $mileage, $color, $description, $location);

            if ($stmt->execute()) {
                $_SESSION['image_type'] = "car";
                header("Location: image.php");

            } else {
                echo "Error: " . $conn->error;
            }

            $stmt->close();
        } else {
            echo "Error: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Car</title>
<style>
    body,html{
            background-image: none !important;
            color: black !important;
        }
    form {
        max-width: 500px;
        margin: 20px auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
        background-color: #f9f9f9;
    }
    label {
        display: block;
        margin-bottom: 5px;
    }
    input[type="text"], input[type="number"], textarea {
        width: 100%;
        padding: 8px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
    input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 4px;
        cursor: pointer;
    }
    .error {
        color: red;
        padding: 10px;
        display: block;
    }
    #h1h1{
        text-align: center;
            color: #333;
        }
</style>
<link rel="shortcut icon" href="image/icon.jpg" type="image/x-icon">
    <link rel="stylesheet" href="css/styles.css" />
</head>
<body>
<?php include('php/header.php'); ?>

<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
<h2 id="h1h1">car selling Form</h2>
    <label for="make">Make:</label>
    <input type="text" id="make" name="make" value="<?php echo isset($make) ? htmlspecialchars($make) : ''; ?>" >
    <?php if (isset($errors['make'])) echo "<span class='error'>{$errors['make']}</span>"; ?>

    <label for="model">Model:</label>
    <input type="text" id="model" name="model" value="<?php echo isset($model) ? htmlspecialchars($model) : ''; ?>" >
    <?php if (isset($errors['model'])) echo "<span class='error'>{$errors['model']}</span>"; ?>

    <label for="year">Year:</label>
    <input type="number" id="year" name="year" value="<?php echo isset($year) ? htmlspecialchars($year) : ''; ?>" min="1900" max="2099" >
    <?php if (isset($errors['year'])) echo "<span class='error'>{$errors['year']}</span>"; ?>

    <label for="price">Price:</label>
    <input type="number" id="price" name="price" value="<?php echo isset($price) ? htmlspecialchars($price) : ''; ?>" min="0" step="0.01" >
    <?php if (isset($errors['price'])) echo "<span class='error'>{$errors['price']}</span>"; ?>

    <label for="mileage">Mileage:</label>
    <input type="number" id="mileage" name="mileage" value="<?php echo isset($mileage) ? htmlspecialchars($mileage) : ''; ?>" min="0" >
    <?php if (isset($errors['mileage'])) echo "<span class='error'>{$errors['mileage']}</span>"; ?>

    <label for="color">Color:</label>
    <input type="text" id="color" name="color" value="<?php echo isset($color) ? htmlspecialchars($color) : ''; ?>" >
    <?php if (isset($errors['color'])) echo "<span class='error'>{$errors['color']}</span>"; ?>

    <label for="description">Description:</label>
    <textarea id="description" name="description" ><?php echo isset($description) ? htmlspecialchars($description) : ''; ?></textarea>
    <?php if (isset($errors['description'])) echo "<span class='error'>{$errors['description']}</span>"; ?>

    <label for="location">Location:</label>
    <input type="text" id="location" name="location" value="<?php echo isset($location) ? htmlspecialchars($location) : ''; ?>" >
    <?php if (isset($errors['location'])) echo "<span class='error'>{$errors['location']}</span>"; ?>

    <input type="submit" value="Submit">
</form>
<?php include('php/footer.php'); ?>
</body>
</html>
