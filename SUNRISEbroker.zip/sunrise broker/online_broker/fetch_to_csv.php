<?php
include('php/userdata.php');
$sql = "SELECT transaction_id, buyer_id, seller_id, listing_type, price, transaction_date, status FROM Transaction WHERE buyer_id = $id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Set headers to download file rather than display
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment;filename="Transaction.csv"');

    $output = fopen('php://output', 'w');

    fputcsv($output, array('Transaction ID', 'Buyer ID', 'Seller ID', 'Listing Type', 'Price', 'Transaction Date', 'Status'));

    while($row = $result->fetch_assoc()) {
        fputcsv($output, $row);
    }

    fclose($output);
} else {
    echo "No results found.";
}
$conn->close();
?>
