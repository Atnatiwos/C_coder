<?php
session_start();
if(!isset($_SESSION['username']) && !isset($_COOKIE['username']) ){
    header("Location: login.php");
    exit();
}
if (isset($_GET['id'])) {
    include('php/userdata.php');

    $id = intval($_GET['id']);
    $sql = "SELECT * FROM images WHERE image_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

    $row = $result->fetch_assoc();
    echo '<img src="data:image/' . $row['type'] . ';base64,' . base64_encode($row['image']) . '" alt="' . htmlspecialchars($row['image_name']) . '" onclick="showActions(' . $row['image_id'] . ')">';
    $cha=htmlspecialchars($row['image_type']);
    $seller_id = htmlspecialchars($row['user_id']);
    $conn->close();
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Transaction</title>
    <link rel="stylesheet" type="text/css" href="css/buy.css">
</head>
<body><?php 
include('php/userdata.php');
$sql = "SELECT * FROM car";
$sq = "SELECT * FROM house";
$result = $conn->query($sql);
$resul = $conn->query($sq);

    $conn->close();
    //header("Location: history.php");

?>

<?php if($cha=="Car"): ?>
<?php if ($result->num_rows > 0): ?>
    <h2>Available Cars</h2>
    <table>
        <tr>
            <th>Make</th>
            <th>Model</th>
            <th>Year</th>
            <th>Price</th>
            <th>Milage</th>
            <th>Description</th>
        </tr>
        <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['make']); ?></td>
                <td><?php echo htmlspecialchars($row['model']); ?></td>
                <td><?php echo htmlspecialchars($row['year']); ?></td>
                <td><?php echo htmlspecialchars($row['price']); ?></td>
                <td><?php echo htmlspecialchars($row['mileage']); ?></td>
                <td><?php echo htmlspecialchars($row['description']); ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
<?php else: ?>
    <p>No cars available.</p>
<?php endif; ?>
<?php endif; ?>

<?php if($cha=="House"): ?>
<?php if ($resul->num_rows > 0): ?>
    <h2>Available house</h2>
    <table>
        <tr>
            <th>Type</th>
            <th>Address</th>
            <th>Year</th>
            <th>Price</th>
            <th>zip code</th>
            <th>bathrooms</th>
            <th>bedrooms</th>
            <th>state</th>
            <th>square feet</th>
            <th>Description</th>
        </tr>
        <?php while($row = $resul->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['type']); ?></td>
                <td><?php echo htmlspecialchars($row['address']); ?></td>
                <td><?php echo htmlspecialchars($row['year_built']); ?></td>
                <td><?php echo htmlspecialchars($row['price']); ?></td>
                <td><?php echo htmlspecialchars($row['zip_code']); ?></td>
                <td><?php echo htmlspecialchars($row['bathrooms']); ?></td>
                <td><?php echo htmlspecialchars($row['bedrooms']); ?></td>
                <td><?php echo htmlspecialchars($row['state']); ?></td>
                <td><?php echo htmlspecialchars($row['square_feet']); ?></td>
                <td><?php echo htmlspecialchars($row['description']); ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
<?php else: ?>
    <p>No cars available.</p>
<?php endif; ?>
<?php endif; ?>

    <div class="container">
        <h2>Add Transaction</h2>
        <form action="add_transaction.php" method="post">
            <label for="buyer_id">Buyer ID:</label>
            <input type="number" id="buyer_id" name="buyer_id"  readonly value="<?php echo $_SESSION['user_id']; ?>">

            <label for="seller_id">Seller ID:</label>
            <input type="number" id="seller_id" name="seller_id" required readonly value="<?php echo $seller_id; ?>">

            <label for="listing_type">Listing Type:</label>
            <input type="text" id="listing_type" name="listing_type" required readonly value="<?php echo $cha; ?>">


            <label for="price">Price:</label>
            <input type="number" id="price" name="price" required>

            <label for="status">Status:</label>
            <select id="status" name="status">
                <option value="Pending">Pending</option>
                <option value="Completed">Completed</option>
                <option value="Cancelled">Cancelled</option>
            </select>

            <input type="submit" value="buy">
        </form>
    </div>
</body>
</html>
