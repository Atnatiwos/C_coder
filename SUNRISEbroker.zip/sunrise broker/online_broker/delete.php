<?php
if (isset($_GET['id'])) {
    include('php/userdata.php');

    $id = intval($_GET['id']);
    $stmt = $conn->prepare("DELETE FROM images WHERE image_id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "Image deleted successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
    header("Location: image.php");
}
?>
